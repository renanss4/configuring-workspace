# Comandos úteis (Ou não)

### PostgreSQL

psql --version

### Atalhos Qt

Ctrl + K = Abre arquivo 

F4 = Find usage

Alt + (Seta para esquerda/direita) = Navega pelo histórico de navegação do cursor

Ctrl + / = Comenta a seleção

F9 = Insere ponto de interrupção

F10 = Depura para passo sobre

F11 = Depura para passso dentro

F2 = Navega até a declaração da variável, função ou classe sob o cursor

CTRL + H = Pesquisa em todos 
