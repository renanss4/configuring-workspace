## Modificadores C++

| Modificador    | Descrição                                                                                             |
| -------------- | ----------------------------------------------------------------------------------------------------- |
| `const`        | Usado para declarar variáveis ou ponteiros constantes.                                                |
| `volatile`     | Indica que uma variável pode ser alterada por eventos externos.                                       |
| `static`       | Pode ser usado para criar variáveis persistentes ou limitar o escopo de variáveis globais.            |
| `extern`       | Usado para declarar variáveis definidas em outros locais.                                             |
| `inline`       | Sugere ao compilador que uma função deve ser inlined para melhorar o desempenho.                      |
| `mutable`      | Usado em membros de classes que podem ser modificados, mesmo em objetos `const`.                      |
| `friend`       | Permite que uma função ou classe acesse membros privados de outra classe.                             |
| `virtual`      | Usado em funções para permitir a substituição em classes derivadas (polimorfismo).                    |
| `override`     | Indica explicitamente que uma função está substituindo uma função na classe base (C++11 em diante).   |
| `final`        | Impede que uma classe seja derivada ou que uma função virtual seja sobrescrita (C++11 em diante).     |
| `decltype`     | Obtém o tipo de uma expressão ou variável.                                                            |
| `auto`         | Permite que o compilador infira o tipo de uma variável com base em seu valor de inicialização.        |
| `register`     | Sugere ao compilador que uma variável deve ser armazenada em um registrador de CPU (raramente usado). |
| `thread_local` | Indica que uma variável tem armazenamento específico de thread (C++11 em diante).                     |
| `constexpr`    | Indica que uma função ou variável pode ser avaliada em tempo de compilação (C++11 em diante).         |
| `typename`     | Usado em templates para especificar que um nome é um tipo.                                            |
| `using`        | Usado para criar alias de tipos ou namespaces.                                                        |
| `nullptr`      | Representa um ponteiro nulo fortemente tipado (C++11 em diante).                                      |
