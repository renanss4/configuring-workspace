# Guida de uso do Audit no Ubuntu



## O que é o Audit?

O Audit é uma ferramenta de monitoramento que acompanha eventos e ações do sistema, promovendo segurança. Será empregado para vigiar operações em diretórios cruciais, como AV1 e Mago64, permitindo rastrear materiais do cliente em caso de exclusão acidental.



### Como instalar:

```bash
sudo apt install auditd 
```



### Copiar as regras já definidas para o diretório de regras do Audit (O arquivo está no Suporte / Projetos / Audit):

```bash
sudo cp mago.rules /etc/audit/rules.d/
```



### Usar o 'agenrules' para poder validar as configurações:

```bash
augenrules --check
```

```bash
augenrules --load
```



### Definir as configurações dos logs:



```bash
sudo nano /etc/audit/auditd.conf
```

##### Alterar as seguintes linhas:

```bash
max_log_file = 10
num_logs = 10    
```



### Reiniciar o serviço do Audit:

```bash
sudo systemctl restart auditd
```



### Verificar se as regras foram aplicadas:

```bash
sudo auditctl -l
```



### A saída deve ser a seguinte:

```bash
-a always,exit -F arch=b64 -S rename,unlink,unlinkat,renameat,renameat2 -F dir=/mnt/AV1 -F key=av1_action
-a always,exit -F arch=b64 -S rename,unlink,unlinkat,renameat,renameat2 -F dir=/home/mago/Mago64 -F key=mago64_action

```



Testes:

---

Testar em uma máquina por um dia com o envio constante de novos arquivos, usar o TesteEnvio.sh


